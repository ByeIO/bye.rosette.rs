use protobuf::reflect::FileDescriptor;
use protobuf::reflect::MessageDescriptor;
use protobuf::MessageDyn;
use protobuf::MessageFull;

/// Recreate generated message file descriptor as dynamic descriptor.
pub fn dynamic_descriptor_for_descriptor<M: MessageFull>() -> MessageDescriptor {
    let file_descriptor = M::descriptor().file_descriptor().clone();
    let dynamic_file_descriptor = FileDescriptor::new_dynamic(
        M::descriptor().file_descriptor_proto().clone(),
        file_descriptor.deps(),
    )
    .unwrap();

    // Find the dynamic version of the generated message.
    let dynamic_descriptor = dynamic_file_descriptor
        .message_by_package_relative_name(M::descriptor().name_to_package())
        .unwrap();

    // This descriptor is equivalent to `M::descriptor()`, but created dynamically
    // using descriptor data stored in generated files.
    dynamic_descriptor
}

/// Serialize message and parse it back as dynamic message.
pub fn recreate_as_dynamic<M: MessageFull>(m: &M) -> Box<dyn MessageDyn> {
    let bytes = m.write_to_bytes().unwrap();
    let dynamic_descriptor = dynamic_descriptor_for_descriptor::<M>();
    dynamic_descriptor.parse_from_bytes(&bytes).unwrap()
}
