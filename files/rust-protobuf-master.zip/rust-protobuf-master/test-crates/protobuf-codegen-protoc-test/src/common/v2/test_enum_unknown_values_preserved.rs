use protobuf::Message;
use protobuf_test_common::*;

use super::test_enum_unknown_values_preserved_pb::*;

#[test]
fn unknown_values_preserved() {
    let mut new = NewMessage::new();
    new.set_eee(NewEnum::C);

    test_serialize_deserialize_with_dynamic("08 1e", &new);

    // `OldEnum` doesn't have variant `C = 30`,
    // but message still properly serialized and deserialized.

    let old: OldMessage = OldMessage::parse_from_bytes(&hex::decode_hex("08 1e")).expect("parse");

    test_serialize_deserialize_with_dynamic("08 1e", &old);
}
